package com.rohit.hogwartsos

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo

private val Ink = Color(0xFF10131B)
private val Plum = Color(0xFF272139)
private val Gold = Color(0xFFD7B879)
private val Glass = Color(0xCC252638)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HogwartsApp() }
    }
}

data class LaunchableApp(val title: String, val info: ResolveInfo)

@Composable
fun HogwartsApp() {
    val context = LocalContext.current
    var controlCentre by remember { mutableStateOf(false) }
    var appDrawer by remember { mutableStateOf(false) }
    var companion by remember { mutableStateOf(false) }
    var drag by remember { mutableFloatStateOf(0f) }
    val apps = remember {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        context.packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map { LaunchableApp(it.loadLabel(context.packageManager).toString(), it) }
            .sortedBy { it.title.lowercase() }
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Ink, surface = Plum)) {
        Box(
            Modifier.fillMaxSize()
                .background(Brush.verticalGradient(listOf(Color(0xFF171827), Ink, Color(0xFF211B2B))))
                .pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onVerticalDrag = { _, amount -> drag += amount },
                        onDragEnd = { if (drag > 35f) { controlCentre = true; appDrawer = false }; drag = 0f }
                    )
                }
        ) {
            if (companion) CompanionScreen(onBack = { companion = false })
            else if (appDrawer) AppDrawer(apps, onBack = { appDrawer = false })
            else HomeScreen(onApps = { appDrawer = true }, onCompanion = { companion = true }, onControl = { controlCentre = true })

            AnimatedVisibility(visible = controlCentre) {
                ControlCentre(onDismiss = { controlCentre = false })
            }
        }
    }
}

@Composable
private fun HomeScreen(onApps: () -> Unit, onCompanion: () -> Unit, onControl: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.SpaceBetween) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("HOGWARTS", color = Gold, letterSpacing = 4.sp, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("School of Witchcraft & Wizardry", color = Color.LightGray.copy(alpha = .7f), fontSize = 11.sp)
            }
            IconButton(onClick = onCompanion) { Icon(Icons.Default.Devices, "Connect devices", tint = Gold) }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Text("✦", color = Gold, fontSize = 34.sp)
            Text("Good day, Wizard", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Light)
            Text("Your magical workspace awaits", color = Color.LightGray.copy(alpha = .65f), fontSize = 13.sp)
            Spacer(Modifier.height(26.dp))
            Surface(color = Glass, shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth().clickable { onControl() }) {
                Column(Modifier.padding(20.dp)) {
                    Text("QUICK ACCESS", color = Gold, fontSize = 10.sp, letterSpacing = 2.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Swipe down to reveal your Control Centre", color = Color.White, fontSize = 15.sp)
                    Text("Liquid Glass • Enchanted controls", color = Color.LightGray, fontSize = 11.sp)
                }
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                DockItem("Apps", Icons.Default.Apps, onApps)
                DockItem("Connect", Icons.Default.Devices, onCompanion)
                DockItem("Controls", Icons.Default.Tune, onControl)
            }
            Spacer(Modifier.height(8.dp))
            Text("HOGWARTS OS  •  ALPHA", color = Gold.copy(alpha = .55f), fontSize = 9.sp, letterSpacing = 2.sp)
        }
    }
}

@Composable
private fun DockItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, action: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { action() }.padding(8.dp)) {
        Surface(color = Color.White.copy(alpha = .10f), shape = CircleShape) {
            Icon(icon, label, tint = Gold, modifier = Modifier.padding(15.dp).size(25.dp))
        }
        Spacer(Modifier.height(5.dp)); Text(label, color = Color.White, fontSize = 11.sp)
    }
}

@Composable
private fun ControlCentre(onDismiss: () -> Unit) {
    val context = LocalContext.current
    var brightness by remember { mutableFloatStateOf(.65f) }
    var volume by remember { mutableFloatStateOf(.55f) }
    var wifi by remember { mutableStateOf(false) }
    var bluetooth by remember { mutableStateOf(false) }
    var torch by remember { mutableStateOf(false) }
    var battery by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .58f)).clickable { onDismiss() }, contentAlignment = Alignment.TopCenter) {
        Column(Modifier.fillMaxWidth().padding(14.dp).background(Glass, RoundedCornerShape(32.dp)).clickable(enabled = false) {}.padding(20.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column { Text("CONTROL CENTRE", color = Gold, fontSize = 11.sp, letterSpacing = 2.sp); Text("The enchanted panel", color = Color.White, fontSize = 20.sp) }
                IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, "Close", tint = Color.White) }
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ToggleTile("Wi-Fi", Icons.Default.Wifi, wifi) { wifi = !wifi; context.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                ToggleTile("Bluetooth", Icons.Default.Bluetooth, bluetooth) { bluetooth = !bluetooth; context.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ToggleTile("Flashlight", Icons.Default.FlashlightOn, torch) { torch = !torch; context.startActivity(Intent("android.settings.SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
                ToggleTile("Battery", Icons.Default.BatterySaver, battery) { battery = !battery; context.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            }
            Spacer(Modifier.height(18.dp))
            Text("BRIGHTNESS", color = Gold, fontSize = 10.sp, letterSpacing = 2.sp)
            Slider(value = brightness, onValueChange = { brightness = it }, colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold))
            Text("VOLUME", color = Gold, fontSize = 10.sp, letterSpacing = 2.sp)
            Slider(value = volume, onValueChange = { volume = it }, colors = SliderDefaults.colors(thumbColor = Gold, activeTrackColor = Gold))
            Spacer(Modifier.height(8.dp))
            Surface(color = Color.White.copy(alpha = .08f), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth().clickable { context.startActivity(Intent(Settings.ACTION_SOUND_SETTINGS)) }) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.MusicNote, null, tint = Gold); Spacer(Modifier.width(10.dp)); Text("Media & sound settings", color = Color.White) }
            }
            Spacer(Modifier.height(12.dp))
            Text("Tap outside or ✕ to close", color = Color.LightGray, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
        }
    }
}

@Composable
private fun ToggleTile(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, active: Boolean, onClick: () -> Unit) {
    Surface(color = if (active) Color(0xFF64533B) else Color.White.copy(alpha = .09f), shape = RoundedCornerShape(18.dp), modifier = Modifier.weight(1f).height(76.dp).clickable { onClick() }) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.Center) { Icon(icon, null, tint = Gold); Spacer(Modifier.height(6.dp)); Text(label, color = Color.White, fontSize = 12.sp) }
    }
}

@Composable
private fun AppDrawer(apps: List<LaunchableApp>, onBack: () -> Unit) {
    val context = LocalContext.current
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Gold) }; Text("Your Applications", color = Color.White, fontSize = 22.sp) }
        LazyVerticalGrid(columns = GridCells.Adaptive(92.dp), contentPadding = PaddingValues(top = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(apps) { app ->
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable {
                    val launch = context.packageManager.getLaunchIntentForPackage(app.info.activityInfo.packageName)
                    if (launch != null) context.startActivity(launch)
                }.padding(8.dp)) {
                    Surface(color = Color.White.copy(alpha = .10f), shape = RoundedCornerShape(20.dp)) {
                        Icon(Icons.Default.Apps, app.title, tint = Gold, modifier = Modifier.size(48.dp).padding(10.dp))
                    }
                    Text(app.title, color = Color.White, fontSize = 11.sp, maxLines = 2)
                }
            }
        }
    }
}

@Composable
private fun CompanionScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Gold) }
        Icon(Icons.Default.Devices, null, tint = Gold, modifier = Modifier.size(42.dp))
        Text("Companion Link", color = Color.White, fontSize = 27.sp)
        Text("Connect your Galaxy S24 FE and Galaxy Tab A9+ with one button.", color = Color.LightGray)
        Surface(color = Glass, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text("PAIRING MODULE NOT YET ACTIVE", color = Gold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text("The Nearby Connections library is included in this project, but device discovery, consent, pairing, and secure data transfer still need implementation and on-device testing.", color = Color.White, fontSize = 13.sp)
            }
        }
        Text("Planned shared features", color = Gold)
        Text("• Send files between devices\n• Share notes and links\n• Continue tasks on the other screen\n• Optional notification mirroring", color = Color.White, lineHeight = 24.sp)
    }
}
