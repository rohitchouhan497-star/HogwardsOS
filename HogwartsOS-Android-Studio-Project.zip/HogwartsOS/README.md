# Hogwarts OS — Android launcher alpha

A native Kotlin + Jetpack Compose Android Studio project scaffold for the Samsung Galaxy S24 FE and Galaxy Tab A9+ (SM-X510).

## Included in this alpha source
- Android HOME/launcher intent registration (the app can be selected as the default Home app after installation).
- Dark academia / Hogwarts-inspired home screen.
- Installed-app drawer with app launch intents.
- Swipe-down-from-anywhere gesture on the launcher surface to open a custom Liquid Glass-style Control Centre overlay.
- Quick links from the panel to Android Wi-Fi, Bluetooth, battery-saver and sound settings.
- Companion screen and Nearby Connections dependency reserved for the next implementation stage.

## Not yet implemented / do not mistake these for working features
- Nearby device discovery, pairing approval, secure transfer, reconnection and actual phone/tablet sync are NOT implemented yet.
- Notification mirroring/listener service is NOT implemented.
- The brightness and volume sliders are currently visual UI controls; they do not yet change system brightness or volume.
- Wi-Fi/Bluetooth tiles open Android settings rather than directly toggling radios. The flashlight tile is also currently a settings shortcut, not a torch controller.
- No APK has been built or device-tested in this environment.

## Build
1. Install Android Studio (current stable) with Android SDK Platform 35 and a compatible Android Gradle Plugin toolchain.
2. Open this folder (`HogwartsOS`) in Android Studio and allow Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the debug APK on the S24 FE and SM-X510 for testing.
5. On each device, select Hogwarts OS as the default Home app in Android Settings > Apps > Default apps > Home app.

The app requests no default-home selection automatically; Android controls that choice. Android versions and Samsung One UI releases can affect permissions and behaviour.

## Package
`com.rohit.hogwartsos`

## Version
`0.1.0` — alpha source scaffold, not a release build.
